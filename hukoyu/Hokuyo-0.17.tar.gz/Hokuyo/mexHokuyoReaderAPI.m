mex -O hokuyoReaderAPI.cc HokuyoReader.cc Hokuyo.cc SerialDevice.cc -DSERIAL_DEVICE_DEBUG
