# Author  : JSP
# Copyright (c) 2006, Mesa Imaging AG
# License : 
# Last modifified : 05.09.2006
# by : JSP

from enthought.tvtk.api import tvtk
from enthought.util import numerix
from enthought.util import scipyx as scipy
import time
#import pythoncom
import array
from array import array as narray
import ctypes
from ctypes import *

try:
	import scipy.special
except ImportError:
	pass

# First create a structured points data set.
sp = tvtk.StructuredPoints(origin=(-72., -88., 0.0),
			   dimensions=(176, 144, 1),
			   spacing=((144.0/176.0), 1.0, 0.0))

# Create some nice data at these points.
x = numerix.arange(-72, 72, 1)
y = numerix.arange(-88, 88, 1)

#SR3000 stuff
AM_COR_FIX_PTRN    = 0x01
AM_COR_LED_NON_LIN = 0x02
AM_MEDIAN          = 0x04
AM_OPT_INT_TIME    = 0x08

srcam    = c_int()
serial   = c_int()
NumBytes = c_int()
size     = c_int()

rows     = c_int()
cols     = c_int()
dev      = int
start    = float

if sys.platform=="win32":
    libc = cdll.LoadLibrary("libMesaSR.dll") #for Windows
else:
    libc = cdll.LoadLibrary("libMesaSR.so") #for Linux

dev  = libc.SR_OpenUSB(byref(srcam),0)

if dev < 0:
	print "SR_Open failed %i" % dev
	print "Script will be terminated"
	sys.exit()
else:
	print "SR_Open OK %i" % dev

print srcam.value
print srcam

rows = libc.SR_GetRows(srcam)
cols = libc.SR_GetCols(srcam)
print "Rows : %i" % rows
print "Cols : %i" % cols
serial = libc.SR_ReadSerial(srcam)
print "Serial : %i 0x%08x" % (serial,serial)

NumBytes = libc.SR_GetBufferSize(srcam)

libc.SR_SetReg(srcam,15,0);

buf  = narray('H', [0] * rows*cols*2) 
intensity = narray('H', [0] * rows*cols) 
xVec = narray('f', [0.0] * rows*cols)
yVec = narray('f', [0.0] * rows*cols)
zVec = narray('f', [0.0] * rows*cols)

libc.SR_SetIntegrationTime(srcam,20)

libc.SR_SetBuffer(srcam, buf.buffer_info()[0], NumBytes);

zPlot = numerix.array([0.0]*rows*cols)

libc.SR_Acquire(srcam, AM_COR_FIX_PTRN or AM_COR_LED_NON_LIN or AM_MEDIAN or AM_OPT_INT_TIME)
libc.SR_CoordTrfFlt(srcam, xVec.buffer_info()[0], yVec.buffer_info()[0], zVec.buffer_info()[0], 4 , 4, 4)

for cc in range(rows*cols) : zPlot[cc] = zVec[cc]
z=numerix.reshape(zPlot,(-1,))

# Now set the scalar data for the StructuredPoints object.  The
# scalars of the structured points object will be a view into our
# Numeric array.  Thus, if we change `z` in-place, the changes will
# automatically affect the VTK arrays.
sp.point_data.scalars = z

# Convert this to a PolyData object.
geom_filter = tvtk.ImageDataGeometryFilter(input=sp)


# Now warp this using the scalar value to generate a carpet plot.
warp = tvtk.WarpScalar(input=geom_filter.output)

# Smooth the resulting data so it looks good.
normals = tvtk.PolyDataNormals(input=warp.output)

# The rest of the VTK pipeline.
m = tvtk.PolyDataMapper(input=normals.output, scalar_range=(min(zVec), max(zVec)))
a = tvtk.Actor(mapper=m)

ren = tvtk.Renderer(background=(0.1, 0.1, 0.1))

ren.add_actor(a)

# Get a nice view.
cam = ren.active_camera
cam.elevation(-45)
cam.azimuth(-60)
cam.dolly(1.35)
#cam.elevation(90)
#cam.yaw(90)
#cam.pitch(90)
#cam.roll(90)
#cam.SetOrientation(0,0,0)

# Create a RenderWindow, add the renderer and set its size.
rw = tvtk.RenderWindow(size=(600, 600))
rw.add_renderer(ren)

# Create the RenderWindowInteractor
rwi = tvtk.RenderWindowInteractor(render_window=rw)
rwi.initialize()
ren.reset_camera()

m.scalar_range = 0.0, 20.0
zScale=20.0 


for i in range(100):
	libc.SR_Acquire(srcam, AM_COR_FIX_PTRN or AM_COR_LED_NON_LIN or AM_MEDIAN or AM_OPT_INT_TIME)
	libc.SR_CoordTrfFlt(srcam, xVec.buffer_info()[0], yVec.buffer_info()[0], zVec.buffer_info()[0], 4 , 4, 4)
	for cc in range(rows*cols) : zPlot[cc] = zVec[cc]*zScale
	z=numerix.reshape(zPlot,(-1,))
	
	# Reset the scalar range.
	#m.scalar_range = min(zPlot), max(zPlot)
	
	# Now explicitly notify `sp` that its data has changed.  If this
	# is not done, VTK has no way of knowing the data changed in order
	# to flush the pipeline.
	sp.modified()
	# Re-render the scene to actually flush the VTK pipeline.
	rwi.render() 
	#time.sleep(0.01) # Just in case your hardware is really fast.
	#pythoncom.PumpWaitingMessages()

# Start the VTK event loop.
rwi.start()
