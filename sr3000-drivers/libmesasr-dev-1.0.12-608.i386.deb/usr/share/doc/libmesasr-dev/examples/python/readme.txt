here are some samples of how to access the libMesaSR from python:

SRdemoBasic.py      is a very basic script that just accquires some images without graphical display.

SRdemoMatPlotLib.py uses the MatPlotLib to visualize the images in 2D it needs the additional packages numpy and MalPlotLib

SRdemoVTK.py        uses the VTK library to visualize the images in 3D. This is under construction and not already fully working.

Here some links were the additional packages can be found:

MatPlotLib     http://matplotlib.sourceforge.net/
numpy          http://numpy.scipy.org/
vtk            http://www.vtk.org/