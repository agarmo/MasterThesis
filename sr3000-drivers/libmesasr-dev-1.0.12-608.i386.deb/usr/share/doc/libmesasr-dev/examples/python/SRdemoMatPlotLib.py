#!/usr/bin/env python
"""
An animated image
"""

import sys
import ctypes
import matplotlib
import matplotlib.pyplot
import numpy as np #array handling for c-interface

import array as ar #python base package array handling

import gobject
import time

def update2(*args):
    global libc, cam
    print "SR_Acquire : %i" % libc.SR_Acquire(cam.srcam)

    #>>>following lines slows down
    z=ar.array('H', [0] * cam.rows*cam.cols)
    ctypes.memmove(z.buffer_info()[0], libc.SR_GetImage( cam.srcam,0), cam.rows*cam.cols*2);
    for x in range(cam.cols) : 
        for y in range(cam.rows) : 
            cam.dist[y] [x]= z[x+y*cam.cols]

    avg=cam.dist.mean()
    std=cam.dist.std()
    cam.im.set_clim(avg-2*std,avg+2*std)
    cam.im.set_array(cam.dist)
    #<<<following lines slows down
    
    cam.manager.canvas.draw()
    cam.cnt += 1
    if cam.cnt==50:
        print 'FPS', cam.cnt/(time.time() - cam.tstart)
        return False
    return True
    
class MesaCam2D:
    def Run(self):
        global libc
        self.srcam = ctypes.c_int()
        
        
        
        #dev  = libc.SR_OpenDlg(byref(srcam),3,0)
        self.dev  = libc.SR_OpenUSB(ctypes.byref(self.srcam), 0)
        #dev  = libc.SR_OpenETH(byref(srcam), "10.0.1.146")

        if self.dev <= 0:
           print "SR_Open failed %i\nScript will terminate" % self.dev
           sys.exit()
        else:
           print "SR_Open OK %i" % self.dev

        serial = libc.SR_ReadSerial(self.srcam)
        print "Serial number : %i 0x%08x" % (serial,serial)

        self.rows = libc.SR_GetRows(self.srcam)
        self.cols = libc.SR_GetCols(self.srcam)
        print "SR_Acquire : %i" % libc.SR_Acquire(self.srcam)
        img=libc.SR_GetImage(self.srcam, 0)

        
        
        x = np.arange(self.cols,dtype='H')
        x = np.resize(x, (self.rows,self.cols))
        y = np.arange(self.rows,dtype='H')
        y = np.resize(y, (self.cols,self.rows))
        y = np.transpose(y)
        Z =x+y
        #Z=np.resize(Z,(self.cols*self.rows, 1))
        self.dist = np.empty([self.rows,self.cols], 'H') # H=unsigned short
        
        self.fig = matplotlib.pyplot.figure(1)
        self.ax = matplotlib.pyplot.subplot(111)
        
        self.dist=Z
        self.im = self.ax.imshow( self.dist, cmap=matplotlib.cm.jet,  extent=(0,self.cols,0,self.rows), interpolation='nearest')
        self.manager = matplotlib.pyplot.get_current_fig_manager()
        
        self.tstart = time.time()
        self.cnt = 0
        gobject.idle_add(update2) #without this the gobject module is not used and no loop is done
        matplotlib.pyplot.show()


        
        self.dist = np.empty([rows,cols], 'H') # H=unsigned short
        self.ampl = np.empty([rows,cols], 'H') # H=unsigned short
        self.x = np.empty([rows,cols], 'f') # f=32 bit float
        self.y = np.empty([rows,cols], 'f') # f=32 bit float
        self.z = np.empty([rows,cols], 'f') # f=32 bit float
     
        #buf       = narray('H', [0] * rows*cols*2) 
        i#ntensity = narray('H', [0] * rows*cols) 
        x = narray('f', [0.0] * rows*cols)
        y = narray('f', [0.0] * rows*cols)
        z = narray('f', [0.0] * rows*cols)
        zPlot     = nparray([0.0]*rows*cols,float)
        iPlot     = nparray([0]*rows*cols,int)

        a=np.arange(10, dtype='uint16')

        
def main():
    global libc, cam
    if sys.platform=="win32":
        libc = ctypes.cdll.LoadLibrary("libMesaSR.dll") #for Windows
    else:
        libc = ctypes.cdll.LoadLibrary("libmesasr.so.1") #for Linux
    matplotlib.use('GTKAgg')
    cam=MesaCam2D()
    cam.Run()

if __name__ == "__main__":
    main()

