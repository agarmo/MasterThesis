from ctypes import *
import sys
import time
from array import array as narray

AM_COR_FIX_PTRN    = 0x01
AM_MEDIAN          = 0x04



srcam = c_int()

if sys.platform=="win32":
    libc = cdll.LoadLibrary("libMesaSR.dll") #for Windows
else:
    libc = cdll.LoadLibrary("libmesasr.so.1") #for Linux

#dev  = libc.SR_OpenDlg(byref(srcam),3,0)
dev  = libc.SR_OpenUSB(byref(srcam), 0)
#dev  = libc.SR_OpenETH(byref(srcam), "10.0.1.133")

if dev <= 0:
   print "SR_Open failed %i" % dev
   print "Script will be terminated"
   sys.exit()
else:
   print "SR_Open OK %i" % dev

rows = libc.SR_GetRows(srcam)
cols = libc.SR_GetCols(srcam)

buf       = narray('H', [0] * rows*cols*2) 
intensity = narray('H', [0] * rows*cols) 
xVec      = narray('f', [0.0] * rows*cols)
yVec      = narray('f', [0.0] * rows*cols)
zVec      = narray('f', [0.0] * rows*cols)

serial = libc.SR_ReadSerial(srcam)
print "Serial number : %i 0x%08x" % (serial,serial)
print "SR_SetMode : %i" % libc.SR_SetMode(srcam, AM_COR_FIX_PTRN or AM_MEDIAN )

start = time.clock()
for ii in range(100):
   start = time.clock()
   print "SR_Acquire : %i" % libc.SR_Acquire(srcam)
   print "Acquire [ms]: ",((time.clock()-start)*1000)

   print libc.SR_CoordTrfFlt(srcam, xVec.buffer_info()[0], yVec.buffer_info()[0], zVec.buffer_info()[0], 4 , 4, 4)
   
   # Get intensity values   
   memmove(intensity.buffer_info()[0], libc.SR_GetImage(srcam,1), rows*cols*2);
   
print "plot [ms]", ((time.clock()-start)*1000)

print "SR_Close : %i" % libc.SR_Close(srcam)
