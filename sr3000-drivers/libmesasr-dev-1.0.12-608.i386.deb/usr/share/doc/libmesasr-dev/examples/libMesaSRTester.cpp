/*------------------------------------------------------------------------*/
/*                                                                        */
/*  Copyright (c) 2008 by MESA Imaging SA,                                */
/*                     http://www.mesa-imaging.ch                         */
/*------------------------------------------------------------------------*/
// $Author$
//    $URL$
//    $Rev$
//   $Date$
/*------------------------------------------------------------------------*/
//!\file
//!Example console application
// libMesaSRTester.cpp : Defines the entry point for the console application.
//
//!\addtogroup libMesaSRTester
//!@{
#include "TestSRCustomer.h"
#ifdef _WIN32
#define set_canon(x)
#else
#include <termios.h>
#include <stdio.h>
#include <unistd.h>

#include <stdlib.h>
#include <linux/sockios.h>
#include <asm/ioctls.h>
#include <sys/select.h>

inline int set_canon(int flag)
{
        struct termios t;
        tcgetattr( fileno(stdin), &t);
        if( flag)
                t.c_lflag |= (ICANON|ECHO);
        else
                t.c_lflag &= ~(ICANON|ECHO);
        tcsetattr( fileno(stdin), TCSANOW, &t); 

        return( 1);
}

#define _getch getchar
#endif

static const char* menu=
"CTestSRCustomer:\n"
" 1: TestBasic\n"
" 2: TestDataDump\n"
" 3: TestTrial\n"
"----------------\n"
"x: exit\n"
"\npress a key";

int MyLibusbCallback(SRCAM srCam, unsigned int msg, unsigned int param, void* data);

//!main function
int main(int argc, char* argv[])
{
  set_canon(0);
  CTestSRCustomer srTester;
  int c;
  SR_SetCallback(MyLibusbCallback);//set global callback
  for(;;)
  {
    puts(CTestSuite::_separator);
    puts(menu);
    c=_getch();
    switch(c)
    {
    case '1':
      srTester.TestBasic();
      break;
    case '2':
      srTester.TestDataDump();
      break;
    case '3':
      srTester.TestTrial();
      break;
    case 'x':
      goto exit;
    }
  }
  puts(CTestSuite::_separator);
  _getch();
exit:
  SR_SetCallback(SR_GetDefaultCallback());//set default global callback
  set_canon(1);
  return 0;
}


