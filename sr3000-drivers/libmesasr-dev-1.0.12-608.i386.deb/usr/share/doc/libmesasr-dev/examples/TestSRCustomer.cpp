/*------------------------------------------------------------------------*/
/*                                                                        */
/*  Copyright (c) 2008 by MESA Imaging SA                                 */
/*                     http://www.mesa-imaging.ch                         */
/*------------------------------------------------------------------------*/
// $Author$
//    $URL$
//    $Rev$
//   $Date$
/*------------------------------------------------------------------------*/
#include "TestSRCustomer.h"
#ifndef _WIN32
  #include <stdio.h>
  #include <stdlib.h>
  #include <termios.h>
  #include <linux/sockios.h>
  #include <asm/ioctls.h>
  #include <sys/select.h>
  #ifndef __BFIN__
    #include <stropts.h>
  #endif
  #include <unistd.h>
  #define _getch getchar

  #include <string.h>
int _kbhit() {
  static const int STDIN = 0;
  static bool initialized = false;

  if (! initialized) {
        // Use termios to turn off line buffering
    termios term;
    tcgetattr(STDIN, &term);
    term.c_lflag &= ~ICANON;
    tcsetattr(STDIN, TCSANOW, &term);
    setbuf(stdin, NULL);
    initialized = true;
  }

  int bytesWaiting;
#ifdef __BFIN__
  bytesWaiting=1;//check were this is...
#else
  ioctl(STDIN, FIONREAD, &bytesWaiting);
#endif
  return bytesWaiting;
}
#endif
CTestSRCustomer* CTestSRCustomer::_lastInstance=0;

#ifndef HIWORD
# define HIWORD(X) ((unsigned short)((unsigned long)(X)>>16))
# define LOWORD(X) ((unsigned short)((unsigned long)(X)&0xFFFF))
#endif
//! local used message callback function to redirect output messages to console
int CTestSRCustomer::LibusbCallback(SRCAM srCam, unsigned int msg, unsigned int param, void* data)
{
  switch(msg)
  {
  case CM_MSG_DISPLAY: // redirects all output to console
    {
      if (param==MC_ETH)
        return 0;
      char*p=(char*)data,*q;
      if(_afterTest)
        _putch('\n');
      while(q=strchr(p,'\n'))
      {
        fputs(_sResStr,stdout);
        fwrite(p,q-p+1,1,stdout);
        p=&q[1];
      }
      fputs(_sResStr,stdout);
      puts((char*)p);
      _afterTest=false;
      return 0;
    }
  case CM_PROGRESS:
    {
      int state   =LOWORD(param);
      int progress=HIWORD(param);
      switch(state)
      {
      case CP_FLASH_ERASE:
        printf("Erasing flash (%d%%)...\n",progress);break;
      case CP_FLASH_WRITE:
        printf("Writing flash (%d%%)...\n",progress);break;
      case CP_FLASH_READ:
        printf("Reading flash (%d%%)...\n",progress);break;
      case CP_FPGA_BOOT:
        printf("Boot FPGA (%d%%)...\n",progress);break;
      case CP_CAM_REBOOT:
        printf("Reboot camera (%d%%)...\n",progress);break;
      case CP_DONE:
        puts("\ndone.");
      }
      return 0;
    }
  default:
    {
      //default handling
      return SR_GetDefaultCallback()(0,msg,param,data);
    }
  }
}

//!function to test various libMesaSR functions.
//!at the end a report shows how many functions runned successfully and how many failed
void CTestSRCustomer::TestBasic()
{
  Reset();
  CMesaDevice* srCam=0;

  int res, numImg, i, defaultMode;
  unsigned int serialNumber=0;
  BYTE uc[4];
  WORD us[4];
  char bufC[1024];
  ImgEntry* imgEntryArray;
  void* data;

  //--------- SR_GetVersion ---------
  {
    unsigned short version[4];
    Run("SR_GetVersion");
    res=SR_GetVersion(version);
    Trace("Version %d.%d.%d.%d",version[3],version[2],version[1],version[0]);
    Result(res==0);
  }
  //--------- SR_CheckForNewDllVersion ---------
#ifdef _WIN32
  Run("SR_CheckForNewDllVersion");
  res=SR_CheckForNewDllVersion(0);     Result(res>=0);
  res=SR_CheckForNewDllVersion(1);     Result(res>=0);
  res=SR_CheckForNewDllVersion(2);     Result(res>=0);
#endif
  //--------- SR_Open ---------
#ifdef __BFIN__
  Run("SR_Open");
  res=SR_Open(&srCam);
#else
  Run("SR_OpenDlg");
  res=SR_OpenDlg(&srCam,3,0);
#endif
  ABORT_ON(res<=0);
  //--------- SR_GetDeviceString ---------
#ifndef __BFIN__
  Run("SR_GetDeviceString");
  res=SR_GetDeviceString(srCam,bufC,_countof(bufC));//returns the device ID used in other calls
  Trace("%s",bufC);
  Result(res>0);
#endif //__BFIN__
  //--------- SR_SetTimeout ---------
  Run("SR_SetTimeout (BLIND)");
  SR_SetTimeout(srCam,100);
  SR_SetTimeout(srCam,1000);    Result(1);
  //--------- Get Rows/Cols ---------
  Run("Get Rows/Cols");
  res=SR_GetRows(srCam);              Result(res==144 || res==160);
  res=SR_GetCols(srCam);              Result(res==176 || res==124);
  //--------- GetImageList ---------
  Run("GetImageList");
  numImg=SR_GetImageList(srCam, &imgEntryArray);   Result(numImg>1 && imgEntryArray!=0);
  //--------- GetImage ---------
  Run("GetImage");
  for(i=0;i<numImg;i++)
  {
    data=SR_GetImage(srCam, i);   Result(data!=0);
  }
  //--------- SR_SetMode ---------
  Run("SR_SetMode");
  defaultMode=SR_GetMode(srCam);
#ifdef __BFIN__
  res=SR_SetMode(srCam,0);   Result(res==0);
#else //__BFIN__
  res=SR_SetMode(srCam,AM_COR_FIX_PTRN|AM_MEDIAN|AM_TOGGLE_FRQ|AM_CONV_GRAY|AM_SW_ANF);   Result(res==0);
  res=SR_Acquire(srCam);
  res=SR_SetMode(srCam,defaultMode);   Result(res==0);
#endif //__BFIN__
  //--------- SR_Acquire ---------
  Run("SR_Acquire");
  {
    int numPix=SR_GetRows(srCam)*SR_GetCols(srCam);
    int numBytes=numImg*numPix*sizeof(WORD);
    for(i=0;i<10;i++)
    {
      res=SR_Acquire(srCam);
      Result(res==numBytes);
    }
    Run("SR_Acquire & SR_CoordTrfXXX 1");
    {
      size_t bufSz=numPix*3*sizeof(float);
      float *buf=(float*)malloc(bufSz);   memset(buf,0xaf,bufSz);
      float *x=buf,           *y=&x[numPix],        *z=&y[numPix];
      int pichX=sizeof(float), pichY=sizeof(float), pichZ=sizeof(float);
      for(i=0;i<10;i++)
      {
        res=SR_Acquire(srCam);
        res=SR_CoordTrfFlt(srCam, 0, 0, z, pichX, pichY, pichZ);     Result(res==0);
        res=SR_CoordTrfFlt(srCam, x, y, z, pichX, pichY, pichZ);     Result(res==0);
      }
      free(buf);
    }

    Run("SR_Acquire & SR_CoordTrfXXX 2");
    {
      size_t bufSz=numPix*3*sizeof(WORD);
      WORD *buf=(WORD*)malloc(bufSz);   memset(buf,0xaf,bufSz);
      short *x=(short*)buf, *y=(short*)&x[numPix];
      WORD  *z=(WORD*)&y[numPix];
      int pichX=sizeof(WORD), pichY=sizeof(WORD), pichZ=sizeof(WORD);
      for(i=0;i<10;i++)
      {
        res=SR_Acquire(srCam);
        res=SR_CoordTrfUint16(srCam, 0, 0, z, pichX, pichY, pichZ);     Result(res==0);
        res=SR_CoordTrfUint16(srCam, x, y, z, pichX, pichY, pichZ);     Result(res==0);
      }
      free(buf);
    }

    Run("SR_Acquire & SR_CoordTrfXXX 3");
    {
      size_t bufSz=numPix*3*sizeof(double);
      double *buf=(double*)malloc(bufSz);   memset(buf,0xaf,bufSz);
      double *x=buf,           *y=&x[numPix],        *z=&y[numPix];
      int pichX=sizeof(double), pichY=sizeof(double), pichZ=sizeof(double);
      for(i=0;i<10;i++)
      {
        res=SR_Acquire(srCam);
        res=SR_CoordTrfDbl(srCam, 0, 0, z, pichX, pichY, pichZ);     Result(res==0);
        res=SR_CoordTrfDbl(srCam, x, y, z, pichX, pichY, pichZ);     Result(res==0);
      }
      free(buf);
    }
  }
  //--------- Get/Set Reg ---------
  Run("Get/Set Reg");
  uc[0]=SR_GetReg(srCam,20);
  uc[1]=(uc[0]+0x3f)^0x73;           Result(uc[0]!=uc[1]);  //an other value...
  res =SR_SetReg(srCam,20,uc[1]);    Result(res==2);
  uc[2]=SR_GetReg(srCam,20);         Result(uc[1]==uc[2]);
  res =SR_SetReg(srCam,20,uc[0]);    Result(res==2);
  uc[3]=SR_GetReg(srCam,20);         Result(uc[0]==uc[3]);

  //--------- Get/Set IntegrationTime ---------
  Run("Get/Set IntegrationTime");
  uc[0]=SR_GetIntegrationTime(srCam);
  uc[1]=(uc[0]+0x3f)^0x73;                    Result(uc[0]!=uc[1]);  //an other value...
  res =SR_SetIntegrationTime(srCam,uc[1]);    Result(res==2);
  uc[2]=SR_GetIntegrationTime(srCam);         Result(uc[1]==uc[2]);
  res =SR_SetIntegrationTime(srCam,uc[0]);    Result(res==2);
  uc[3]=SR_GetIntegrationTime(srCam);         Result(uc[0]==uc[3]);

  //--------- Get/SetAmplitudeThreshold ---------
  Run("Get/SetAmplitudeThreshold");
  us[0]=SR_GetAmplitudeThreshold(srCam);
  us[1]=(us[0]+0x523f)^0x13c9;                   Result(us[0]!=us[1]);  //an other value...
  res =SR_SetAmplitudeThreshold(srCam,us[1]);    Result(res==4);
  us[2]=SR_GetAmplitudeThreshold(srCam);         Result(us[1]==us[2]);
  res =SR_SetAmplitudeThreshold(srCam,us[0]);    Result(res==4);
  us[3]=SR_GetAmplitudeThreshold(srCam);         Result(us[0]==us[3]);

  //--------- Get/SetDistanceOffset ---------
  Run("Get/SetDistanceOffset");
  us[0]=SR_GetDistanceOffset(srCam);
  us[1]=(us[0]+0x523f)^0x13c9;               Result(us[0]!=us[1]);  //an other value...
  res =SR_SetDistanceOffset(srCam,us[1]);    Result(res>=2);
  us[2]=SR_GetDistanceOffset(srCam);         Result((us[1]&0xff)==(us[2]&0xff)); //check only lsb (sr3k)
  res =SR_SetDistanceOffset(srCam,us[0]);    Result(res>=2);
  us[3]=SR_GetDistanceOffset(srCam);         Result(us[0]==us[3]);

  //--------- SR_SetAutoExposure ---------
  Run("SR_SetAutoExposure");
  res=SR_SetAutoExposure(srCam, 0,255,10,45);
  Result(res==0);

#ifdef _WIN32
  Run("SR_StreamToFile");
  {
    char tmpName[MAX_PATH];//alternative _tempnam
    GetTempPath(_countof(tmpName),tmpName);
    res=GetTempFileName(tmpName,"tmpSR",0,tmpName);     Result(res!=0);
    //char tmpName[]={"//tmp//libMesaSR.XXXXXX"};
    //mkstemp(tmpName);
    SR_StreamToFile(srCam,tmpName,0);
    for(i=1;i<5;i++)
    {
      res=SR_Acquire(srCam);
    }
    SR_StreamToFile(srCam,tmpName,2);
    struct _stat st;
    int numPix=SR_GetRows(srCam)*SR_GetCols(srCam);
    res=_stat(tmpName,&st);   Result(res==0&& st.st_size>=numPix*5*2);
    res=_unlink(tmpName);      Result(res==0);
  }
#endif
  //--------- SR_Close ---------
  Run("SR_Close");
  res=SR_Close(srCam);
  Result(res==0);
  //--------- RESULTS -----------------------
  ReportSummary();
}

//!function to test basic operation of the libMesaSR interface.
//!it opens the device with SR_OpenUSB() then acquires one images and dumps its data on request
void CTestSRCustomer::TestDataDump()
{
  char cmd;
  CMesaDevice* srCam;
  int res;

  printf("This Testcode uses the new libMesaSR interface with the libusb device driver\n");

#ifdef __BFIN__
  Run("SR_Open");
  res=SR_Open(&srCam);
#else
  Run("SR_OpenDlg");
  res=SR_OpenDlg(&srCam,3,0);
#endif
  //res=SR_OpenUSB(&srCam,0);//returns the device ID used in other calls.
  //res=SR_OpenETH(&srCam,"10.0.1.146");//returns the device ID used in other calls.
  printf("libusbTester: SR_OpenXXX() called result:%d\n",res);
  if(res<0)
  {
    printf("libusbTester: SR_OpenXXX() falied. abort Test.");
    return;
  }

  for(cmd='\n';cmd!='x';)
  {
    res=SR_Acquire(srCam);
    ImgEntry* imgEntryArray;
    SR_GetImageList(srCam, &imgEntryArray);
    void* buf=imgEntryArray[0].data;
    int w,h;
    w=SR_GetCols(srCam);
    h=SR_GetRows(srCam);
  
    printf("libusbTester: SR_Acquire() called result:%d\n",res);
    //-----------------------------------------------------------
    //insert code here to process the acquired 3D data.
    //To query the format of the acquired data use the functions
    //SR_GetRows(), SR_GetCols(), SR_GetNumImg(), SR_GetBytePerPix()
    //that are described in the Swissranger.chm help file
    {
      printf("continue acquire?<any key>, dump data?<d>, exit?<x>:",cmd);cmd=_getch();
      putchar(cmd);
      switch(cmd)
      {
        case 'd':
          Dump((unsigned char*)buf,(int)w*h*2);
          //no break;
       default:
          break;
        case 'x':
          goto exitLoop;
          puts("unknown cmd");
      }
    }
  }
exitLoop:
  //-----------------------------------------------------------

  res=SR_Close(srCam);
  printf("libusbTester: SR_Close() called result:%d\n",res);
}


void CTestSRCustomer::TestTrial()
{
  CMesaDevice* srCam;
  int res;
  int w,h,i,j;
  Reset();
  Run("CTestSRCustomer::Trial");

#ifdef __BFIN__
  Run("SR_Open");
  res=SR_Open(&srCam);
#else
  Run("SR_OpenDlg");
  res=SR_OpenDlg(&srCam,3,0);
  //res=SR_OpenETH(&srCam,"10.0.1.109");
#endif
  ImgEntry* imgEntryArray;
  SR_SetReg(srCam,4,1);//Debug Data
  SR_SetIntegrationTime(srCam,5);
  w=SR_GetCols(srCam);
  h=SR_GetRows(srCam);
  SR_GetImageList(srCam, &imgEntryArray);
  unsigned short* buf=(unsigned short*)imgEntryArray[0].data;

  for(j=0;;)
  {
    for(i=0;i<1000;i++,j++)
    {
      res=SR_Acquire(srCam);
      if(res!=w*h*2*2)
      {
        printf("libusbTester ERROR: SR_Acquire() called result:%d\n",res);
      }
      printf("%d pixel data : %.4x %.4x %.4x %.4x %.4x %.4x %.4x %.4x\r",j+1,
             (int)(buf[0]),(int)(buf[1]),(int)(buf[2]),(int)(buf[3]),
             (int)(buf[4]),(int)(buf[5]),(int)(buf[6]),(int)(buf[7]));fflush(stdout);
      if(_kbhit())
        goto exitLoop;
    }
    putchar('\n');
  }
exitLoop:

  res=SR_Close(srCam);
  printf("libusbTester: SR_Close() called result:%d\n",res);

  Result(1);
  ReportSummary();
}

//!@} libMesaSRTester
