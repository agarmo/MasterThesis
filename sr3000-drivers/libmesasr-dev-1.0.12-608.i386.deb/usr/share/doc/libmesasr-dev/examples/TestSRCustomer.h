/*------------------------------------------------------------------------*/
/*                                                                        */
/*  Copyright (c) 2008 by MESA Imaging SA                                 */
/*                     http://www.mesa-imaging.ch                         */
/*------------------------------------------------------------------------*/
// $Author$
//    $URL$
//    $Rev$
//   $Date$
/*------------------------------------------------------------------------*/
#pragma once
#ifdef _WIN32
#include <sys/stat.h> //stat
#include <conio.h> //_putch,_getch
#include <Windows.h> //WORD, DWORD etc
#else
#define _putch putchar
#define _vsnprintf vsnprintf
#define _unlink unlink
#define MAX_PATH 260
typedef unsigned char  BYTE;
typedef unsigned long  DWORD;
int _kbhit();
#endif

#include "TestSuite.h"
#include "libMesaSR.h"

#ifdef _WIN32
  #pragma comment( lib, "libMesaSR.lib" )
#endif

class CTestSRCustomer :public CTestSuite
{
public:
  CTestSRCustomer(){_lastInstance=this;}
  static CTestSRCustomer* GetLastInstance(){return _lastInstance;}
  //Test Functions:
  int LibusbCallback(SRCAM srCam, unsigned int msg, unsigned int param, void* data);
  void TestDataDump();
  void TestBasic();
  void TestTrial();
private:
  static CTestSRCustomer* _lastInstance;
};

__inline int MyLibusbCallback(SRCAM srCam, unsigned int msg, unsigned int param, void* data)
{
  CTestSRCustomer* testSR=CTestSRCustomer::GetLastInstance();
  if(testSR)
    return testSR->LibusbCallback(srCam, msg, param, data);
  return 0;
}
